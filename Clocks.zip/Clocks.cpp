
/*
Michele Medve
CS210
Project1
Chada Tech Clocks

This program is designed to display a 12-hour clock and a 24-hour clock with proper formatting to the console at the same time, with a starting time of 12.
The program also prompts the user for input to manipulate the clocks and display the desired action to the console for both clocks simultaneously.
The program ends when the user enters the number 4, indicating they would like to exit. 
*/

#include <iostream>
#include <string>
#include<iomanip>
using namespace std;


//function that determines if the time is AM or PM given the 24 hour clock hour. 
string meridian(int h) {
	
	string amOrPm;
	
	if (h >= 12) {
		amOrPm = "P M";
	}
	else {
		amOrPm = "A M";
	}
	
	return amOrPm;
}



int main(){

	int hour=12, twelvehour = 12, minute=0, second =0, userChoice = 0; //variable declarations

	while (userChoice != 4) { //loop while the user does not want to exit the program
		//displays clocks to console 
		//calls the meridian function to determine meridian for 12-hour clock given the 24-hour clock hour as a parameter
		cout << "**************************\t**************************" << endl;
		cout << "*\t12-Hour Clock \t *\t*\t24-Hour Clock\t *" << endl;
		std::cout << "*\t" << std::setfill('0') << std::setw(2) << twelvehour << ":" << std::setfill('0') << std::setw(2) << minute << ":" 
			<< std::setfill('0') << std::setw(2) << second << " " << meridian(hour) << "\t *\t*\t  " << std::setfill('0') << std::setw(2) 
			<< hour << ":" << std::setfill('0') << std::setw(2) << minute << ":" << std::setfill('0') << std::setw(2) << second << "\t *" << endl;
		cout << "**************************\t**************************" << endl << endl;


		//displays selection choices to console
		cout << "**************************" << endl;
		cout << "*1 - Add One Hour \t * " << endl;
		cout << "*2 - Add One Minute \t * " << endl;
		cout << "*3 - Add One Second \t * " << endl;
		cout << "*4 - Exit Program \t * " << endl;
		cout << "**************************" << endl;
		
		cin >> userChoice; //takes user input 

		//switch case based on the selection the user inputs
		switch (userChoice) {
			case 1: //adds one hour
				if (hour <= 22) {
					hour += 1;
				}
				else {
					hour = 0;
				}
				if (twelvehour < 12) {
					twelvehour += 1;
				}
				else {
					twelvehour = 1;
				}
				break;
			case 2: //adds one minute
				if (minute < 59) {
						minute = +1;
				}
				else {
					minute = 0;
					hour += 1;
					twelvehour += 1;
				}
				break;
			case 3: //adds one second
				if (second < 59) {
					second = second +1;
				}
				else {
					second = 0;
					minute += 1;
				}
				break;
			case 4: //leaves the switch
				break; 

		}

	}


	return 0;
}